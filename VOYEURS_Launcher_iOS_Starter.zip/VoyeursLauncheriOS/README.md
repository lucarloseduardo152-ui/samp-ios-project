# VOYEURS RPG — Launcher iOS (protótipo de interface)

Este projeto contém os arquivos SwiftUI iniciais para um launcher exclusivo do servidor **191.233.26.192:7777**. Cor principal: **#66CDAA**.

## Estado do projeto

- Interface inicial com nickname salvo localmente, marca VOYEURS RPG e endpoint fixo.
- O botão **JOGAR** informa que a integração de um cliente multiplayer é necessária.
- **Não inclui GTA San Andreas, motor do jogo, cliente SA-MP, conexão jogável ou arquivos proprietários.**
- **Não é um IPA** e não pode ser instalado diretamente pelo ESign.

## Abrir no Xcode

1. No macOS, crie um novo projeto iOS do tipo *App* em SwiftUI, chamado `VoyeursLauncher`.
2. Substitua o `App.swift` e `ContentView.swift` gerados pelos arquivos fornecidos, e adicione `ServerConfig.swift` ao target.
3. Selecione o iPhone como destino e configure *Signing & Capabilities* com sua conta de desenvolvedor.
4. Compile e teste. Para exportar um IPA distribuível, você precisa do processo de assinatura apropriado no Xcode.

## Próxima etapa técnica

Identificar/licenciar um cliente GTA San Andreas Multiplayer **realmente funcional e compatível com iOS**, analisar permissões e API de integração e implementar uma ponte de inicialização para o IP/porta fixos. Um APK Android não pode ser convertido simplesmente para um IPA jogável.
