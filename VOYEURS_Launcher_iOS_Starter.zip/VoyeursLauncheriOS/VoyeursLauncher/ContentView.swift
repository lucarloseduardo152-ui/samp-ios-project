import SwiftUI

struct ContentView: View {
    @AppStorage("nickname") private var nickname = ""
    @State private var showClientAlert = false
    private let accent = Color(red: 0x66 / 255, green: 0xCD / 255, blue: 0xAA / 255)

    var body: some View {
        ZStack {
            Color(red: 0.055, green: 0.075, blue: 0.09).ignoresSafeArea()
            VStack(spacing: 24) {
                Spacer()
                Text("VOYEURS")
                    .font(.system(size: 40, weight: .black, design: .rounded))
                    .foregroundStyle(accent)
                Text("RPG • iOS LAUNCHER")
                    .font(.headline)
                    .foregroundStyle(.white)
                Text("SERVIDOR EXCLUSIVO")
                    .font(.caption.bold())
                    .foregroundStyle(accent)
                Text("\(ServerConfig.host):\(ServerConfig.port)")
                    .font(.system(.body, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.8))
                TextField("Digite seu nickname", text: $nickname)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding()
                    .background(.white.opacity(0.11), in: RoundedRectangle(cornerRadius: 12))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 28)
                Button {
                    showClientAlert = true
                } label: {
                    Text("JOGAR")
                        .font(.title3.bold())
                        .frame(maxWidth: .infinity)
                        .padding(16)
                        .background(accent, in: RoundedRectangle(cornerRadius: 14))
                        .foregroundStyle(.black)
                }
                .padding(.horizontal, 28)
                .accessibilityHint("Informa que a integração com o cliente multiplayer ainda está pendente")
                Text("Protótipo da interface. Ainda não executa GTA SA-MP.")
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.65))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                Spacer()
            }
        }
        .alert("Cliente multiplayer necessário", isPresented: $showClientAlert) {
            Button("Entendi", role: .cancel) {}
        } message: {
            Text("O launcher está configurado para VOYEURS RPG, mas não inclui um cliente GTA San Andreas Multiplayer para iOS. É preciso integrar e testar um cliente compatível antes de jogar.")
        }
    }
}
