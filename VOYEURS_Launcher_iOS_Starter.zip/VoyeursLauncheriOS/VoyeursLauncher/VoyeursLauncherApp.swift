import SwiftUI

@main
struct VoyeursLauncherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
