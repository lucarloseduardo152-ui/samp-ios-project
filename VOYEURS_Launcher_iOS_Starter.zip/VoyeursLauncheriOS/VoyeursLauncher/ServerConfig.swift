import Foundation

enum ServerConfig {
    static let title = "VOYEURS RPG"
    static let host = "191.233.26.192"
    static let port: UInt16 = 7777
    static let accentHex = 0x66CDAA
}
